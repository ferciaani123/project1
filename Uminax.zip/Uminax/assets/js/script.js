
$(document).ready(function () {
  $(".he_eng_2").hide();
  $(".he_eng_1").click(function () {
      $(".he_eng_2").toggle();
      $(".he_eng_4").hide();
  });

});
$(document).ready(function () {
  $(".he_eng_4").hide();
  $(".he_eng_3").click(function () {
      $(".he_eng_4").toggle();
      $(".he_eng_2").hide();
  });

});
$(document).ready(function () {
  $("#whish_li").hide();
  $("#whish_li_1").click(function () {
      $("#whish_li").show();
      $("#whish_li_1").hide();
  });
});
$(document).ready(function () {
  $("#whish_li_mob").hide();
  $("#whish_li_1_mob").click(function () {
      $("#whish_li_mob").show();
      $("#whish_li_1_mob").hide();
  });
});
$(document).ready(function () {
  $(".he_bro_2").hide();
  $(".he_bro").click(function () {
      $(".he_bro_2").toggle();
  });

});

$(document).ready(function () {
  $(".top_selling_3_mob2").hide();
  $("h5#top_selling_3_mob1").click(function () {
      $(".top_selling_3_mob2").toggle();
  });
});
function openNav() {
  document.getElementById("mySidenav").style.width = "390px";
  document.getElementById("overlay1").style.display = "block";
  // button.innerHTML = "<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-arrow-clockwise' viewBox='0 0 16 16'> <path fill-rule='evenodd' d='M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2v1z'/><path d='M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466z'/></svg> Loaded";
  // button.disabled = true;
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("overlay1").style.display = "none";
}

function openNav_1() {
  document.getElementById("mySidenav_1").style.width = "390px";
  document.getElementById("overlay1").style.display = "block";
}

function closeNav_1() {
  document.getElementById("mySidenav_1").style.width = "0";
  document.getElementById("overlay1").style.display = "none";
}

function openNav_4() {
  document.getElementById("mySidenav_4").style.width = "390px";
  document.getElementById("overlay").style.display = "block";
}
function closeNav_4() {
  document.getElementById("mySidenav_4").style.width = "0";
  document.getElementById("overlay").style.display = "none";
  document.getElementById("mySidenav_5").style.width = "0";
  document.getElementById("mySidenav_6").style.width = "0";
  document.getElementById("mySidenav_7").style.width = "0";
  document.getElementById("mySidenav_8").style.width = "0";
}
function openNav_5() {
  document.getElementById("mySidenav_5").style.width = "390px";

}

function closeNav_5() {
  document.getElementById("mySidenav_5").style.width = "0";
}
function openNav_6() {
  document.getElementById("mySidenav_6").style.width = "390px";
}

function closeNav_6() {
  document.getElementById("mySidenav_6").style.width = "0";
}
function openNav_7() {
  document.getElementById("mySidenav_7").style.width = "390px";

}

function closeNav_7() {
  document.getElementById("mySidenav_7").style.width = "0";
}
function openNav_8() {
  document.getElementById("mySidenav_8").style.width = "390px";

}

function closeNav_8() {
  document.getElementById("mySidenav_8").style.width = "0";
}
function sub_1(){
  document.getElementById("overlay2").style.display = "block";
  document.querySelector('Subtotal_re_1').style.display = "block";
}
function off_sub(){
  document.getElementById("overlay2").style.display = "none";
  document.querySelector('Subtotal_re_1').style.display = "none";
}

/*mobile*/

function openNav_2() {
  document.getElementById("mySidenav_2").style.width = "100%";
}

function closeNav_2() {
  document.getElementById("mySidenav_2").style.width = "0";
}
function openNav_3() {
  document.getElementById("mySidenav_3").style.width = "100%";
}

function closeNav_3() {
  document.getElementById("mySidenav_3").style.width = "0";
}
function openNav_9() {
document.getElementById("mySidenav_9").style.width = "100%";
}

function closeNav_9() {
document.getElementById("mySidenav_9").style.width = "0";
document.getElementById("overlay1").style.display = "none";
}
function openNav_10() {
  document.getElementById("mySidenav_12").style.width = "100%";
  }
  
  function closeNav_10() {
  document.getElementById("mySidenav_12").style.width = "0";

  }
  function openNav_11() {
    document.getElementById("mySidenav_11").style.width = "100%";
    }
    
    function closeNav_11() {
    document.getElementById("mySidenav_11").style.width = "0";
    }
function off() {
document.getElementById("overlay").style.display = "none";
document.getElementById("mySidenav_4").style.width = "0";
document.getElementById("mySidenav_5").style.width = "0";
document.getElementById("mySidenav_6").style.width = "0";
document.getElementById("mySidenav_7").style.width = "0";
document.getElementById("mySidenav_8").style.width = "0";
document.getElementById("mySidenav").style.width = "0";
document.getElementById("mySidenav_1").style.width = "0";
document.getElementById("overlay2").style.display = "none";
}
function off_1() {
document.getElementById("overlay1").style.display = "none";
document.getElementById("mySidenav").style.width = "0";
document.getElementById("mySidenav_1").style.width = "0";
document.getElementById("overlay2").style.display = "none";

}
function blogopenNav() {
  document.getElementById("myblogSidenav").style.width = "295px";
  document.getElementById("overlay1").style.display = "block";
}

function blogcloseNav() {
  document.getElementById("myblogSidenav").style.width = "0";
  document.getElementById("overlay1").style.display = "none";
}
function off_left_1(){
  document.getElementById("overlay1").style.display = "none";
  document.getElementById("myblogSidenav").style.width = "0";
}
// show more less btn
+function myFunction() {
var dots = document.getElementById("custom-checks");
var moreText = document.getElementById("custom-check");
var btnText = document.getElementById("showMoreBtn");

if (dots.style.display === "none") {
  dots.style.display = "inline";
  btnText.innerHTML = "+ Show more"; 
  moreText.style.display = "none";
} else {
  dots.style.display = "none";
  btnText.innerHTML = "- Show less"; 
  moreText.style.display = "inline";
}
}


$(document).ready(function () {
$(".spr-content").hide();
$("span.spr-summary-actions").click(function () {
    $(".spr-content").toggle();
});
});

// sticky 
document.addEventListener("DOMContentLoaded", function(){
window.addEventListener('scroll', function() {
    if (window.scrollY > 0) {
      document.getElementById('navbar').classList.add('fixed-top');
      // add padding top to show content behind navbar
      navbar_height = document.querySelector('.navbar').offsetHeight;
     
    } else {
      document.getElementById('navbar').classList.remove('fixed-top');
       // remove padding top from body
      document.body.style.paddingTop = '50';
    } 
});
});
document.addEventListener("DOMContentLoaded", function () {
var acc = document.getElementsByClassName("faq_accord");
var i;

for (i = 0; i < acc.length; i++) {
    var faq_accord_1 = acc[i].nextElementSibling;
    faq_accord_1.style.maxHeight = faq_accord_1.scrollHeight + "px"; // Open the content by default

    acc[i].addEventListener("click", function () {
        this.classList.toggle("active");
        var faq_accord_1 = this.nextElementSibling;
        if (faq_accord_1.style.maxHeight) {
            faq_accord_1.style.maxHeight = null; // Close the content
        } else {
            faq_accord_1.style.maxHeight = faq_accord_1.scrollHeight + "px"; // Open the content
        }
    });
}
});
document.addEventListener("DOMContentLoaded", function () {
var acc = document.getElementsByClassName("faq_accord1");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function () {
        // Toggle the 'active' class on the clicked h4 element
        this.classList.toggle("active");

        // Find the corresponding faq_accord_2 element
        var faq_accord_2 = this.nextElementSibling;

        // Toggle the max-height to show/hide the content
        if (faq_accord_2.style.maxHeight) {
            faq_accord_2.style.maxHeight = null; // Close the content
        } else {
            faq_accord_2.style.maxHeight = faq_accord_2.scrollHeight + "px"; // Open the content
        }
    });
}
});
$(document).ready(function () {
$(".Subtotal_re_1").hide();
$("p.Subtotal_po_1").click(function () {
    $(".Subtotal_re_1").toggle();
});
$("#overlay2").click(function () {
  $(".Subtotal_re_1").hide();
});
});
$(function(){

  //Scroll event
  $(window).scroll(function(){
    var scrolled = $(window).scrollTop();
    if (scrolled > 200) $('.go-top').fadeIn('slow');
    if (scrolled < 200) $('.go-top').fadeOut('slow');
  });
  
  //Click event
  $('.go-top').click(function () {
    $("html, body").animate({ scrollTop: "0" },  500);
  });
  
  });