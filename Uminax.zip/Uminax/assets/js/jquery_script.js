
$(document).ready(function () {
    $(".accordions").click(function () {
        $(".panels").toggle();
    });
});
$(document).ready(function () {
    $(".accordion_1").click(function () {
        $(".panel_1").toggle();
    });
});
$(document).ready(function () {
    $(".accordion_2").click(function () {
        $(".panel_2").toggle();
    });
});
$(document).ready(function () {
    $(".accordion_3").click(function () {
        $(".panel_3").toggle();
    });
});
$(document).ready(function () {
    $(".accordion_4").click(function () {
        $(".accord_open").toggle();
    });
});
document.addEventListener("DOMContentLoaded", function () {
    var acc = document.getElementsByClassName("accord_price");
    var i;

    for (i = 0; i < acc.length; i++) {
        var accord_price_1 = acc[i].nextElementSibling;
        accord_price_1.style.maxHeight = accord_price_1.scrollHeight + "px"; // Open the content by default

        acc[i].addEventListener("click", function () {
            this.classList.toggle("active");
            var accord_price_1 = this.nextElementSibling;
            if (accord_price_1.style.maxHeight) {
                accord_price_1.style.maxHeight = null; // Close the content
            } else {
                accord_price_1.style.maxHeight = accord_price_1.scrollHeight + "px"; // Open the content
            }
        });
    }
});
document.addEventListener("DOMContentLoaded", function () {
    var acc = document.getElementsByClassName("accord_price1");
    var i;

    for (i = 0; i < acc.length; i++) {
        var accord_price_2 = acc[i].nextElementSibling;
        accord_price_2.style.maxHeight = accord_price_2.scrollHeight + "px"; // Open the content by default

        acc[i].addEventListener("click", function () {
            this.classList.toggle("active");
            var accord_price_2 = this.nextElementSibling;
            if (accord_price_2.style.maxHeight) {
                accord_price_2.style.maxHeight = null; // Close the content
            } else {
                accord_price_2.style.maxHeight = accord_price_2.scrollHeight + "px"; // Open the content
            }
        });
    }
});
// SHOW MORE AND LESS BTN
// document.addEventListener("DOMContentLoaded", function () {
//     var showMoreBtn = document.getElementById("showMoreBtn");
//     var accordItems = document.querySelectorAll(".form-check");

//     function toggleContent() {
//         for (var i = accordItems.length - 3; i < accordItems.length; i++) {
//             accordItems[i].style.display = accordItems[i].style.display === "none" ? "block" : "none";
//         }
//         showMoreBtn.textContent = showMoreBtn.textContent === "- Show Less" ? "+ Show More" : "- Show Less";
//     }

   
//     toggleContent();

//     showMoreBtn.addEventListener("click", toggleContent);
// });



document.addEventListener("DOMContentLoaded", function () {
    var acc = document.getElementsByClassName("accord_price2");
    var i;

    for (i = 0; i < acc.length; i++) {
        var accord_price_3 = acc[i].nextElementSibling;
        accord_price_3.style.maxHeight = accord_price_3.scrollHeight + "px"; // Open the content by default

        acc[i].addEventListener("click", function () {
            this.classList.toggle("active");
            var accord_price_3 = this.nextElementSibling;
            if (accord_price_3.style.maxHeight) {
                accord_price_3.style.maxHeight = null; // Close the content
            } else {
                accord_price_3.style.maxHeight = accord_price_3.scrollHeight + "px"; // Open the content
            }
        });
    }
});






